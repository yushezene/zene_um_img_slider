const images = ["image1.jpeg", "image2.jpeg", "image3.jpeg", "image4.jpeg", "image5.jpeg"];
let currentImageIndex = 0;
const slider = document.querySelector('.slider');
const positionIndicator = document.querySelector('.slider-position');
const intervalTime = 2000; // 2 seconds
let slideshowInterval;

function showImage(index) {
    const newSlide = document.createElement('div');
    newSlide.classList.add('slide');
    newSlide.innerHTML = `<img src="${images[index]}" alt="Image ${index + 1}">`;

    slider.style.opacity = '0';
    setTimeout(() => {
        slider.innerHTML = ''; // Clear existing content
        slider.appendChild(newSlide);
        slider.style.opacity = '3';
        updateSliderPosition(index);
    }, 120); //  timing as needed for the transition effect
}

function prevImage() {
    currentImageIndex = (currentImageIndex - 1 + images.length) % images.length;
    showImage(currentImageIndex);
}

function nextImage() {
    currentImageIndex = (currentImageIndex + 1) % images.length;
    showImage(currentImageIndex);
}

function updateSliderPosition(index) {
    positionIndicator.textContent = `${index + 1} / ${images.length}`;
}

// Automatically transition to the next mage every 3 seconds
function startSlideshow() {
    slideshowInterval = setInterval(nextImage, intervalTime);
}

function stopSlideshow() {
    clearInterval(slideshowInterval);
}

function toggleSlideshow() {
    const toggleButton = document.getElementById('toggleSlideshow');
    if (slideshowInterval) {
        stopSlideshow();
        toggleButton.textContent = 'Start Slideshow';
    } else {
        startSlideshow();
        toggleButton.textContent = 'Stop Slideshow';
    }
}

// Display the first image and position indicator when the page loads
document.addEventListener("DOMContentLoaded", () => {
    showImage(currentImageIndex);
    updateSliderPosition(currentImageIndex);
});
